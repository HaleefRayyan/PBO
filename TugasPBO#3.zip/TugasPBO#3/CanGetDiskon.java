public interface CanGetDiskon {
    public Integer hitungTotalBayar(Integer jumlahBelanja);
}